v1 = """
/* feedback checkbox */
.css-18fuwiq {
 position: relative;
 padding-top: 6px;
}
.css-949r0i {
 position: relative;
 padding-top: 6px;
}

"""
