STORAGE_MODE=LOCAL
CACHE_MODE=DISK

STORAGE_PATH=../data/storage
CACHE_PATH=../data/cache

streamlit run gui.py
