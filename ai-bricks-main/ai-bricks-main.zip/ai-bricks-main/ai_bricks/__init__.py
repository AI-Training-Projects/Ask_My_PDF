#import ai_bricks.api

#def model(model_code, **kw):
#	provider,_,name = model_code.partition(':')
#	# TODO: refactor ???
#	if provider=='openai':
#		return api.openai.model(name, **kw)
#	elif provider=='cohere':
#		return api.cohere.model(name, **kw)
#	elif provider=='anthropic':
#		return api.anthropic.model(name, **kw)

